package com.home.currency;

import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btnGo;
    private EditText edntd;
    private double USDRATE = 30.9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edntd = (EditText)findViewById(R.id.ntd);
        btnGo = (Button)findViewById(R.id.button);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s_nt = edntd.getText().toString();

                if(s_nt.equals("")) {
                    FillNumber();
                }
                else{
                    int NTD = Integer.valueOf(s_nt);
                    TranferUSD(NTD);
                }

            }
        });
    }
    private void FillNumber(){
        new AlertDialog.Builder(MainActivity.this)
                .setTitle(R.string.problem)
                .setMessage(R.string.plcase_center_ntd)
                .setPositiveButton(R.string.ok, null)
                .show();
    }
    private void TranferUSD(int NTD){
        float usd = (float) (NTD/USDRATE);
        new AlertDialog.Builder(MainActivity.this)
                .setTitle(R.string.result)
                .setMessage(getString(R.string.usd_is) + usd)
                .setPositiveButton(R.string.ok, null)
                .show();
    }

}